-- phpMyAdmin SQL Dump
-- version 4.4.14.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 21, 2016 at 10:43 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtestion`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL,
  `firstname` varchar(55) NOT NULL,
  `lastname` varchar(55) NOT NULL,
  `email` varchar(32) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `division` varchar(100) NOT NULL,
  `zip` int(55) NOT NULL,
  `age` int(33) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` int(2) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `firstname`, `lastname`, `email`, `address`, `city`, `division`, `zip`, `age`, `created_date`, `updated_date`, `status`) VALUES
(1, 'Md.Tarikul ', 'Islam ', 'tarikul@gmail.com', 'Mirpur 01, Dhaka 1216', 'Dhaka', 'Dhaka', 1216, 27, '2016-06-22 04:00:00', 0, 1),
(2, 'Rony', 'Kader', 'rony@gmail.com', 'Chardulai,Dulai,Pabna', 'Pabna', 'Rajshai', 6600, 28, '2016-06-22 02:00:00', 0, 1),
(3, 'Kader', 'Shaik', 'kader@gmail.com', 'Chardulai,Dulai,Pabna', 'Pabna', 'Rajshai', 6600, 55, '2016-06-22 02:00:00', 0, 1),
(4, 'Taleb', 'Kader', 'talib@gmail.com', 'Chardulai,Dulai,comilla', 'Comilla', 'Comilla', 1600, 32, '2016-06-22 02:00:00', 0, 1),
(5, 'Latif', 'Shaik', 'latif@gmail.com', 'Vula,Dulai,Vula', 'Vula', 'Barisal', 2200, 60, '2016-06-22 02:00:00', 0, 1),
(6, 'Monorar', 'Shaik', 'mono@gmail.com', 'Rangamati,Chitagong', 'Rangamati', 'Chitagong', 3232, 32, '2016-06-22 02:00:00', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL,
  `orderNumber` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `customersId` int(11) NOT NULL,
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `orderNumber`, `productId`, `customersId`, `created_time`, `updated_time`, `status`) VALUES
(1, 1, 1, 1, '2016-06-22 03:00:00', '0000-00-00 00:00:00', 1),
(2, 2, 3, 4, '2016-06-22 00:00:10', '0000-00-00 00:00:00', 1),
(3, 3, 3, 1, '2016-06-22 03:00:00', '0000-00-00 00:00:00', 1),
(4, 4, 5, 4, '2016-06-22 00:00:10', '0000-00-00 00:00:00', 1),
(5, 5, 5, 1, '2016-06-22 00:00:10', '0000-00-00 00:00:00', 1),
(6, 6, 2, 4, '2016-06-22 00:00:10', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL,
  `productName` varchar(250) NOT NULL,
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  `status` tinyint(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `productName`, `created_time`, `updated_time`, `status`) VALUES
(1, 'Product one', '2016-06-22 02:00:00', '0000-00-00 00:00:00', 1),
(2, 'Product Two', '2016-06-22 02:05:00', '0000-00-00 00:00:00', 1),
(3, 'Product three', '2016-06-22 02:00:00', '0000-00-00 00:00:00', 1),
(4, 'Product four', '2016-06-22 02:05:00', '0000-00-00 00:00:00', 1),
(5, 'Product five', '2016-06-22 02:05:00', '0000-00-00 00:00:00', 1),
(6, 'Product six', '2016-06-22 02:05:00', '0000-00-00 00:00:00', 1),
(7, 'Product seven', '2016-06-22 02:05:00', '0000-00-00 00:00:00', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
